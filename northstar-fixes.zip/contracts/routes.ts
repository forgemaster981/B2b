/** Public pages served by the SPA. Shared by the server (404 vs 200), sitemap generator and tests. */
export const SPA_ROUTES = ["/", "/about", "/projects", "/lab", "/insights", "/studio", "/contact", "/privacy"] as const;

/** Legacy paths answered with a permanent redirect. */
export const REDIRECTS: Record<string, string> = { "/services": "/studio" };

/** Routes listed in sitemap.xml, with priority. Privacy stays indexable but low priority. */
export const SITEMAP_PRIORITY: Record<string, string> = { "/": "1.0", "/studio": "0.9", "/contact": "0.9", "/privacy": "0.3" };
