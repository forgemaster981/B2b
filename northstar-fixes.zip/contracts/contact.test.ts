import { describe, expect, it } from "vitest";
import { contactSchema } from "./contact";
import { REDIRECTS, SPA_ROUTES } from "./routes";

const valid = {
  name: "  Jane Doe ",
  email: "  Jane@Example.COM ",
  inquiryType: "business",
  message: "I would like a simple website for my bakery.",
  website: "",
  submissionId: "3f2b8c1e-5d4a-4e6b-9a7c-1b2c3d4e5f60",
  formToken: "1800000000000.".padEnd(78, "a"),
};

describe("contactSchema", () => {
  it("trims and normalises valid input", () => {
    const parsed = contactSchema.parse(valid);
    expect(parsed.name).toBe("Jane Doe");
    expect(parsed.email).toBe("jane@example.com");
  });

  it("rejects a filled honeypot, short messages, bad emails and unknown inquiry types", () => {
    expect(contactSchema.safeParse({ ...valid, website: "http://spam" }).success).toBe(false);
    expect(contactSchema.safeParse({ ...valid, message: "too short" }).success).toBe(false);
    expect(contactSchema.safeParse({ ...valid, email: "nope" }).success).toBe(false);
    expect(contactSchema.safeParse({ ...valid, inquiryType: "sales" }).success).toBe(false);
  });

  it("enforces length caps and requires the submission id and form token", () => {
    expect(contactSchema.safeParse({ ...valid, message: "x".repeat(3001) }).success).toBe(false);
    expect(contactSchema.safeParse({ ...valid, name: "x".repeat(81) }).success).toBe(false);
    expect(contactSchema.safeParse({ ...valid, submissionId: "not-a-uuid" }).success).toBe(false);
    expect(contactSchema.safeParse({ ...valid, formToken: "" }).success).toBe(false);
  });
});

describe("routes", () => {
  it("redirects only to known pages", () => {
    for (const target of Object.values(REDIRECTS)) expect(SPA_ROUTES).toContain(target);
  });
});
