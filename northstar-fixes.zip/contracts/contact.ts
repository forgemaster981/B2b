import { z } from "zod";

export const inquiryTypes = ["business", "project", "collaboration", "other"] as const;

/** Fields the visitor controls; validated in the browser and again on the server. */
export const contactFieldsSchema = z.object({
  name: z.string().trim().min(2, "Please enter at least 2 characters.").max(80, "Please keep your name under 80 characters."),
  email: z.string().trim().toLowerCase().email("Enter a valid email address.").max(254),
  inquiryType: z.enum(inquiryTypes, "Choose an inquiry type."),
  message: z.string().trim().min(20, "Please add a little more detail (at least 20 characters).").max(3000, "Please keep your message under 3,000 characters."),
  website: z.string().max(0),
  submissionId: z.string().uuid(),
});

/** Full server input: the visitor fields plus the signed token issued by `contact.formToken`. */
export const contactSchema = contactFieldsSchema.extend({
  formToken: z.string().min(20).max(200),
});

export type ContactFields = z.infer<typeof contactFieldsSchema>;
export type ContactInput = z.infer<typeof contactSchema>;
