// Operator tooling. Inquiries have no public read endpoint, so this is how you read them.
//   npm run admin -- list [limit]
//   npm run admin -- retry
//   npm run admin -- purge <days>
import { closeDb } from "../api/queries/connection";
import { listRecentInquiries, listUndeliveredInquiries, markNotification, purgeInquiriesOlderThan, purgeStaleRateLimits } from "../api/queries/inquiries";
import { sendInquiryNotification } from "../api/services/contact";

async function main() {
  const [command, arg] = process.argv.slice(2);
  switch (command) {
    case "list": {
      const limit = Math.min(Math.max(Number(arg) || 20, 1), 200);
      for (const row of await listRecentInquiries(limit)) {
        console.log(`\n[${row.createdAt.toISOString()}] ${row.reference.slice(0, 8)} · ${row.inquiryType} · email:${row.notificationStatus}\n${row.name} <${row.email}>\n${row.message}`);
      }
      break;
    }
    case "retry": {
      let sent = 0;
      let failed = 0;
      for (const row of await listUndeliveredInquiries()) {
        try {
          const result = await sendInquiryNotification({ reference: row.reference, name: row.name, email: row.email, inquiryType: row.inquiryType, message: row.message });
          await markNotification(row.id, result.status);
          if (result.status === "sent") sent += 1;
        } catch (error) {
          await markNotification(row.id, "failed");
          failed += 1;
          console.error(`Failed ${row.reference.slice(0, 8)}: ${error instanceof Error ? error.message : String(error)}`);
        }
      }
      console.log(`Notifications sent: ${sent}, failed: ${failed}. Unconfigured email stays pending until RESEND_API_KEY and CONTACT_TO_EMAIL are set.`);
      break;
    }
    case "purge": {
      const days = Number(arg);
      if (!Number.isInteger(days) || days < 1) throw new Error("Usage: purge <days>  (days must be a positive integer)");
      const inquiriesRemoved = await purgeInquiriesOlderThan(days);
      const limitsRemoved = await purgeStaleRateLimits();
      console.log(`Deleted ${inquiriesRemoved} inquiries older than ${days} days and ${limitsRemoved} stale rate-limit rows.`);
      break;
    }
    default:
      throw new Error("Usage: admin <list [limit] | retry | purge <days>>");
  }
}

main()
  .catch((error) => {
    console.error(error instanceof Error ? error.message : error);
    process.exitCode = 1;
  })
  .finally(() => closeDb());
