import { index, int, mysqlTable, serial, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const inquiries = mysqlTable("inquiries", {
  id: serial("id").primaryKey(),
  reference: varchar("reference", { length: 36 }).notNull().unique(),
  submissionId: varchar("submission_id", { length: 36 }).notNull().unique(),
  fingerprint: varchar("fingerprint", { length: 64 }).notNull(),
  name: varchar("name", { length: 80 }).notNull(),
  email: varchar("email", { length: 254 }).notNull(),
  inquiryType: varchar("inquiry_type", { length: 24 }).notNull(),
  message: text("message").notNull(),
  notificationStatus: varchar("notification_status", { length: 20 }).notNull().default("pending"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
}, (table) => [
  index("inquiry_fingerprint_created_idx").on(table.fingerprint, table.createdAt),
  index("inquiry_created_idx").on(table.createdAt),
]);

export const inquiryRateLimits = mysqlTable("inquiry_rate_limits", {
  id: serial("id").primaryKey(),
  ipHash: varchar("ip_hash", { length: 64 }).notNull().unique(),
  windowStartedAt: timestamp("window_started_at").notNull(),
  attempts: int("attempts").notNull().default(0),
}, (table) => [
  index("rate_limit_window_idx").on(table.windowStartedAt),
]);
