import { initTRPC } from "@trpc/server";
import superjson from "superjson";
import type { TrpcContext } from "./context";
import { describeError } from "./lib/dberror";
import { log } from "./lib/logger";

const t = initTRPC.context<TrpcContext>().create({
  transformer: superjson,
  // tRPC returns error.message to the browser verbatim. Drizzle/mysql2 messages contain the SQL
  // text and bound parameters (visitor PII), and Zod input errors are raw JSON. Neither belongs in
  // a response, so both are replaced; the real cause goes to the server log without parameters.
  errorFormatter({ shape, error }) {
    if (error.code === "INTERNAL_SERVER_ERROR") {
      log.error("trpc procedure failed", {
        path: shape.data?.path,
        code: error.code,
        ...describeError(error),
        stack: error.stack?.split("\n").slice(0, 8).join("\n"),
      });
      return { ...shape, message: "Something went wrong on our side. Please try again in a moment." };
    }
    if (error.code === "BAD_REQUEST" && shape.message.trimStart().startsWith("[")) {
      return { ...shape, message: "Some fields are invalid. Please check the form and try again." };
    }
    return shape;
  },
});

export const createRouter = t.router;
export const publicQuery = t.procedure;
