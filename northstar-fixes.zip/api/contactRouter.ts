import { TRPCError } from "@trpc/server";
import { contactSchema } from "@contracts/contact";
import { createRouter, publicQuery } from "./middleware";
import { env } from "./lib/env";
import { isDuplicateEntryError } from "./lib/dberror";
import { hashValue, issueFormToken, requestIp, sendInquiryNotification, verifyFormToken } from "./services/contact";
import { checkAndRecordAttempt, createInquiry, findBySubmissionId, findRecentDuplicate, markNotification } from "./queries/inquiries";

const tokenMessages = {
  invalid: "This form session was not valid. Please try sending again.",
  expired: "This form session expired. Please try sending again.",
  too_fast: "Please take a moment to review your message, then try again.",
} as const;

export const contactRouter = createRouter({
  // Signed timestamp the form must send back; proves the page was loaded and the form was open for a moment.
  formToken: publicQuery.query(() => ({ token: issueFormToken() })),

  submit: publicQuery.input(contactSchema).mutation(async ({ ctx, input }) => {
    if (input.website) {
      throw new TRPCError({ code: "BAD_REQUEST", message: tokenMessages.invalid });
    }
    const tokenState = verifyFormToken(input.formToken);
    if (tokenState !== "ok") {
      throw new TRPCError({ code: "BAD_REQUEST", message: tokenMessages[tokenState] });
    }

    const ipHash = hashValue(requestIp(ctx.req.headers, ctx.remoteAddress, env.trustProxyHops));
    if (!await checkAndRecordAttempt(ipHash)) {
      throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Too many attempts. Please wait 15 minutes and try again." });
    }

    const fingerprint = hashValue(`${input.email}|${input.inquiryType}|${input.message}`);
    const duplicate = await findRecentDuplicate(fingerprint);
    if (duplicate) return { reference: duplicate.reference, saved: true, notification: "duplicate" as const };

    const reference = crypto.randomUUID();
    let id: number;
    try {
      id = await createInquiry({
        reference,
        submissionId: input.submissionId,
        fingerprint,
        name: input.name,
        email: input.email,
        inquiryType: input.inquiryType,
        message: input.message,
        notificationStatus: "pending",
      });
    } catch (error) {
      // A retry of the same submission (e.g. after a dropped response) hits the unique submission_id.
      if (isDuplicateEntryError(error)) {
        const existing = await findBySubmissionId(input.submissionId);
        if (existing) return { reference: existing.reference, saved: true, notification: "duplicate" as const };
      }
      throw error;
    }

    try {
      const result = await sendInquiryNotification({ reference, name: input.name, email: input.email, inquiryType: input.inquiryType, message: input.message });
      await markNotification(id, result.status);
      return { reference, saved: true, notification: result.status };
    } catch {
      await markNotification(id, "failed").catch(() => undefined);
      return { reference, saved: true, notification: "failed" as const };
    }
  }),
});
