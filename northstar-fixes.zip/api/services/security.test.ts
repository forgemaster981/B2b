import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { hashValue, issueFormToken, requestIp, verifyFormToken } from "./contact";

beforeEach(() => { vi.stubEnv("CONTACT_HASH_SECRET", "test-secret-test-secret-test-secret-123"); });
afterEach(() => { vi.unstubAllEnvs(); });

describe("form token", () => {
  const issuedAt = 1_800_000_000_000;

  it("accepts a token that is old enough and fresh enough", () => {
    expect(verifyFormToken(issueFormToken(issuedAt), issuedAt + 5_000)).toBe("ok");
  });

  it("rejects submissions faster than 3 seconds", () => {
    expect(verifyFormToken(issueFormToken(issuedAt), issuedAt + 1_000)).toBe("too_fast");
  });

  it("rejects tokens older than 6 hours", () => {
    expect(verifyFormToken(issueFormToken(issuedAt), issuedAt + 6 * 3_600_000 + 1)).toBe("expired");
  });

  it("rejects tokens from the future, forged timestamps, forged signatures and garbage", () => {
    const token = issueFormToken(issuedAt);
    const [, signature] = token.split(".");
    expect(verifyFormToken(token, issuedAt - 1)).toBe("invalid");
    expect(verifyFormToken(`${issuedAt - 60_000}.${signature}`, issuedAt + 5_000)).toBe("invalid");
    expect(verifyFormToken(`${issuedAt}.${"0".repeat(signature.length)}`, issuedAt + 5_000)).toBe("invalid");
    expect(verifyFormToken(`${issuedAt}.short`, issuedAt + 5_000)).toBe("invalid");
    expect(verifyFormToken("not-a-token", issuedAt + 5_000)).toBe("invalid");
    expect(verifyFormToken(`${token}.extra`, issuedAt + 5_000)).toBe("invalid");
  });

  it("does not validate tokens signed with a different secret", () => {
    const token = issueFormToken(issuedAt);
    vi.stubEnv("CONTACT_HASH_SECRET", "another-secret-another-secret-12345678");
    expect(verifyFormToken(token, issuedAt + 5_000)).toBe("invalid");
  });
});

describe("hashValue", () => {
  it("is deterministic, keyed and never returns the input", () => {
    const first = hashValue("203.0.113.9");
    expect(hashValue("203.0.113.9")).toBe(first);
    expect(first).toMatch(/^[0-9a-f]{64}$/);
    expect(first).not.toContain("203.0.113.9");
    vi.stubEnv("CONTACT_HASH_SECRET", "another-secret-another-secret-12345678");
    expect(hashValue("203.0.113.9")).not.toBe(first);
  });

  it("refuses to run in production without a secret", () => {
    vi.stubEnv("CONTACT_HASH_SECRET", "");
    vi.stubEnv("NODE_ENV", "production");
    expect(() => hashValue("x")).toThrow("CONTACT_HASH_SECRET");
  });
});

describe("requestIp", () => {
  const headers = (xff?: string) => new Headers(xff ? { "x-forwarded-for": xff } : {});

  it("ignores X-Forwarded-For when no proxy is trusted (spoofing attempt)", () => {
    expect(requestIp(headers("1.1.1.1"), "10.0.0.5", 0)).toBe("10.0.0.5");
  });

  it("uses the entry appended by the trusted proxy, not the client-supplied prefix", () => {
    expect(requestIp(headers("6.6.6.6, 203.0.113.9"), "10.0.0.5", 1)).toBe("203.0.113.9");
    expect(requestIp(headers("6.6.6.6, 203.0.113.9, 10.1.1.1"), "10.0.0.5", 2)).toBe("203.0.113.9");
  });

  it("falls back to the socket address when the chain is shorter than the trusted hops", () => {
    expect(requestIp(headers(), "10.0.0.5", 1)).toBe("10.0.0.5");
    expect(requestIp(headers("203.0.113.9"), undefined, 2)).toBe("unknown");
  });
});
