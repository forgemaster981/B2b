import { createHmac, timingSafeEqual } from "node:crypto";

const FORM_TOKEN_MIN_AGE_MS = 3_000;
const FORM_TOKEN_MAX_AGE_MS = 6 * 60 * 60 * 1000;

function secret(): string {
  const value = process.env.CONTACT_HASH_SECRET;
  if (value) return value;
  if (process.env.NODE_ENV === "production") throw new Error("CONTACT_HASH_SECRET is required in production");
  return "development-only-contact-secret";
}

function hmac(purpose: string, value: string): string {
  return createHmac("sha256", secret()).update(`${purpose}\0${value}`).digest("hex");
}

/** One-way keyed hash used for IP rate-limit keys and duplicate fingerprints. */
export function hashValue(value: string): string {
  return hmac("hash", value);
}

/**
 * Resolve the visitor IP. X-Forwarded-For is only trusted for the number of reverse proxies
 * the operator declared; each trusted proxy appends the address it saw, so the client is the
 * entry `hops` positions from the end. Anything to the left is client-controlled and ignored.
 */
export function requestIp(headers: Headers, remoteAddress: string | undefined, trustedProxyHops: number): string {
  if (trustedProxyHops > 0) {
    const chain = (headers.get("x-forwarded-for") ?? "").split(",").map((part) => part.trim()).filter(Boolean);
    const candidate = chain[chain.length - trustedProxyHops];
    if (candidate) return candidate;
  }
  return remoteAddress || "unknown";
}

/** Server-issued, signed timestamp. Replaces a client-supplied "startedAt" that bots could forge. */
export function issueFormToken(now: number = Date.now()): string {
  const issuedAt = String(now);
  return `${issuedAt}.${hmac("form", issuedAt)}`;
}

export type FormTokenState = "ok" | "invalid" | "expired" | "too_fast";

export function verifyFormToken(token: string, now: number = Date.now()): FormTokenState {
  const [issuedAt, signature, extra] = token.split(".");
  if (!issuedAt || !signature || extra !== undefined || !/^\d{10,15}$/.test(issuedAt)) return "invalid";
  const expected = Buffer.from(hmac("form", issuedAt));
  const received = Buffer.from(signature);
  if (expected.length !== received.length || !timingSafeEqual(expected, received)) return "invalid";
  const age = now - Number(issuedAt);
  if (age < 0) return "invalid";
  if (age > FORM_TOKEN_MAX_AGE_MS) return "expired";
  if (age < FORM_TOKEN_MIN_AGE_MS) return "too_fast";
  return "ok";
}

function escapeHtml(value: string) {
  return value.replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" })[character]!);
}

export async function sendInquiryNotification(input: { reference: string; name: string; email: string; inquiryType: string; message: string }) {
  const apiKey = process.env.RESEND_API_KEY;
  const to = process.env.CONTACT_TO_EMAIL;
  if (!apiKey || !to) return { status: "unconfigured" as const };
  const from = process.env.CONTACT_FROM_EMAIL || "Northstar Website <onboarding@resend.dev>";
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from,
      to: [to],
      reply_to: input.email,
      subject: `[${input.inquiryType}] New Northstar inquiry · ${input.reference.slice(0, 8)}`,
      text: `Reference: ${input.reference}\nName: ${input.name}\nEmail: ${input.email}\nType: ${input.inquiryType}\n\n${input.message}`,
      html: `<h1>New website inquiry</h1><p><strong>Reference:</strong> ${escapeHtml(input.reference)}</p><p><strong>Name:</strong> ${escapeHtml(input.name)}</p><p><strong>Email:</strong> ${escapeHtml(input.email)}</p><p><strong>Type:</strong> ${escapeHtml(input.inquiryType)}</p><hr><p>${escapeHtml(input.message).replace(/\n/g, "<br>")}</p>`,
    }),
    signal: AbortSignal.timeout(10_000),
  });
  if (!response.ok) throw new Error(`Email provider rejected notification (${response.status})`);
  return { status: "sent" as const };
}
