import type { FetchCreateContextFnOptions } from "@trpc/server/adapters/fetch";

export type TrpcContext = {
  req: Request;
  resHeaders: Headers;
  /** Socket peer address of the TCP connection (the proxy, when behind one). */
  remoteAddress?: string;
};

export async function createContext(
  opts: FetchCreateContextFnOptions,
  remoteAddress?: string,
): Promise<TrpcContext> {
  return { req: opts.req, resHeaders: opts.resHeaders, remoteAddress };
}
