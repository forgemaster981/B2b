import { Hono } from "hono";
import { bodyLimit } from "hono/body-limit";
import { compress } from "hono/compress";
import { sql } from "drizzle-orm";
import type { HttpBindings } from "@hono/node-server";
import { fetchRequestHandler } from "@trpc/server/adapters/fetch";
import { appRouter } from "./router";
import { createContext } from "./context";
import { env } from "./lib/env";
import { describeError } from "./lib/dberror";
import { log } from "./lib/logger";
import { handleClientLog } from "./lib/clientlog";
import { REQUEST_ID_HEADER, runWithRequestId } from "./lib/requestcontext";
import { closeDb, getDb } from "./queries/connection";

const app = new Hono<{ Bindings: HttpBindings }>();

// Security headers on every response. The CSP is production-only: in development the Vite dev server
// serves pages (and needs inline scripts / websockets for HMR), and this app only answers /api/*.
app.use("*", async (c, next) => {
  await next();
  const headers = c.res.headers;
  headers.set("X-Content-Type-Options", "nosniff");
  headers.set("X-Frame-Options", "DENY");
  headers.set("Referrer-Policy", "strict-origin-when-cross-origin");
  headers.set("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=(), usb=()");
  headers.set("Cross-Origin-Opener-Policy", "same-origin");
  if (c.req.path.startsWith("/api/")) headers.set("Cache-Control", "no-store");
  if (env.isProduction) {
    headers.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
    headers.set("Content-Security-Policy", [
      "default-src 'self'",
      "script-src 'self'",
      // 'unsafe-inline' for styles only: React sets inline style attributes (progress bar).
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
      "font-src 'self' https://fonts.gstatic.com data:",
      "img-src 'self' data:",
      "connect-src 'self'",
      "frame-ancestors 'none'",
      "base-uri 'self'",
      "form-action 'self'",
      "object-src 'none'",
      "upgrade-insecure-requests",
    ].join("; "));
  }
});

if (env.isProduction) app.use("*", compress());

// Request id (echoed to the client) plus one access-log line per /api request.
app.use("*", async (c, next) => {
  const requestId = crypto.randomUUID();
  if (c.req.path === "/api/log") {
    await next();
    return;
  }
  const start = Date.now();
  await runWithRequestId(requestId, async () => {
    await next();
    c.res.headers.set(REQUEST_ID_HEADER, requestId);
    if (!c.req.path.startsWith("/api/")) return;
    log.info("request", { method: c.req.method, path: c.req.path, status: c.res.status, durationMs: Date.now() - start });
  });
});

// The contact form sends well under 8 KB. Scoped to the tRPC route on purpose: a global bodyLimit
// breaks bodyless requests on the Vite dev server.
app.use("/api/trpc/*", bodyLimit({ maxSize: 16 * 1024, onError: (c) => c.json({ error: "Payload Too Large" }, 413) }));
app.use("/api/trpc/*", async (c) => {
  const remoteAddress = c.env?.incoming?.socket?.remoteAddress;
  return fetchRequestHandler({
    endpoint: "/api/trpc",
    req: c.req.raw,
    router: appRouter,
    createContext: (opts) => createContext(opts, remoteAddress),
  });
});

// Browser log sink: development only. In production it would be an unauthenticated write endpoint.
if (!env.isProduction) {
  app.post("/api/log", bodyLimit({ maxSize: 64 * 1024, onError: (c) => c.body(null, 413) }), handleClientLog);
}

// Liveness + database readiness for load balancers and uptime monitors. Reveals no internals.
app.get("/api/health", async (c) => {
  try {
    await getDb().execute(sql`select 1`);
    return c.json({ status: "ok" });
  } catch (error) {
    log.error("health check failed", describeError(error));
    return c.json({ status: "unavailable" }, 503);
  }
});

app.all("/api/*", (c) => c.json({ error: "Not Found" }, 404));

app.onError((err, c) => {
  log.error("unhandled request error", { method: c.req.method, path: c.req.path, ...describeError(err) });
  return c.json({ error: "Internal Server Error" }, 500);
});

export default app;

if (env.isProduction) {
  const { serve } = await import("@hono/node-server");
  const { serveStaticFiles } = await import("./lib/vite");
  serveStaticFiles(app);
  const port = parseInt(process.env.PORT || "3000", 10);
  const server = serve({ fetch: app.fetch, port }, () => {
    log.info(`Server running on http://localhost:${port}/`);
  });

  let shuttingDown = false;
  const shutdown = (signal: string) => {
    if (shuttingDown) return;
    shuttingDown = true;
    log.info("shutting down", { signal });
    const force = setTimeout(() => process.exit(1), 10_000);
    force.unref();
    server.close(() => {
      closeDb().catch(() => undefined).finally(() => process.exit(0));
    });
  };
  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("SIGINT", () => shutdown("SIGINT"));
  process.on("unhandledRejection", (reason) => log.error("unhandled rejection", describeError(reason)));
}
