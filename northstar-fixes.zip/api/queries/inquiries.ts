import { and, desc, eq, gt, inArray, lt, sql } from "drizzle-orm";
import { inquiries, inquiryRateLimits } from "@db/schema";
import { getDb } from "./connection";

export const RATE_LIMIT_WINDOW_MS = 15 * 60 * 1000;
export const RATE_LIMIT_MAX_ATTEMPTS = 5;

type NotificationStatus = "sent" | "failed" | "unconfigured";

/**
 * Records one attempt for this hashed IP and returns whether it is still within the limit.
 * All timestamps are supplied by the application (never SQL NOW()) so comparisons stay in one clock.
 */
export async function checkAndRecordAttempt(ipHash: string, now: Date = new Date()) {
  const db = getDb();
  const windowStart = new Date(now.getTime() - RATE_LIMIT_WINDOW_MS);
  await db.insert(inquiryRateLimits).values({ ipHash, windowStartedAt: now, attempts: 1 })
    .onDuplicateKeyUpdate({
      set: {
        attempts: sql`CASE WHEN ${inquiryRateLimits.windowStartedAt} < ${windowStart} THEN 1 ELSE ${inquiryRateLimits.attempts} + 1 END`,
        windowStartedAt: sql`CASE WHEN ${inquiryRateLimits.windowStartedAt} < ${windowStart} THEN ${now} ELSE ${inquiryRateLimits.windowStartedAt} END`,
      },
    });
  const [limit] = await db.select().from(inquiryRateLimits).where(eq(inquiryRateLimits.ipHash, ipHash)).limit(1);
  return Boolean(limit && limit.attempts <= RATE_LIMIT_MAX_ATTEMPTS);
}

export async function createInquiry(data: Omit<typeof inquiries.$inferInsert, "createdAt" | "id">) {
  const [result] = await getDb().insert(inquiries).values({ ...data, createdAt: new Date() }).$returningId();
  return result.id;
}

export async function findRecentDuplicate(fingerprint: string) {
  const since = new Date(Date.now() - RATE_LIMIT_WINDOW_MS);
  const [existing] = await getDb().select({ reference: inquiries.reference }).from(inquiries)
    .where(and(eq(inquiries.fingerprint, fingerprint), gt(inquiries.createdAt, since))).limit(1);
  return existing;
}

export async function findBySubmissionId(submissionId: string) {
  const [existing] = await getDb().select({ reference: inquiries.reference }).from(inquiries)
    .where(eq(inquiries.submissionId, submissionId)).limit(1);
  return existing;
}

export async function markNotification(id: number, status: NotificationStatus) {
  await getDb().update(inquiries).set({ notificationStatus: status }).where(eq(inquiries.id, id));
}

/* ---- Operator tooling (CLI only; there is intentionally no public read endpoint) ---- */

export async function listRecentInquiries(limit: number) {
  return getDb().select().from(inquiries).orderBy(desc(inquiries.createdAt)).limit(limit);
}

export async function listUndeliveredInquiries() {
  return getDb().select().from(inquiries)
    .where(inArray(inquiries.notificationStatus, ["pending", "failed", "unconfigured"]))
    .orderBy(inquiries.createdAt);
}

export async function purgeInquiriesOlderThan(days: number) {
  const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  const [result] = await getDb().delete(inquiries).where(lt(inquiries.createdAt, cutoff));
  return result.affectedRows;
}

export async function purgeStaleRateLimits() {
  const cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000);
  const [result] = await getDb().delete(inquiryRateLimits).where(lt(inquiryRateLimits.windowStartedAt, cutoff));
  return result.affectedRows;
}
