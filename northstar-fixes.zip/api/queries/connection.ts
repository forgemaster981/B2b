import { drizzle, type MySql2Database } from "drizzle-orm/mysql2";
import { createPool } from "mysql2";
import { env } from "../lib/env";
import * as schema from "@db/schema";
import * as relations from "@db/relations";

const fullSchema = { ...schema, ...relations };

type Database = MySql2Database<typeof fullSchema>;

let instance: Database | undefined;
let closePool: (() => Promise<void>) | undefined;

export function getDb(): Database {
  if (!instance) {
    const pool = createPool({
      uri: env.databaseUrl,
      // JS Dates are sent as UTC and each connection is pinned to UTC below, so rate-limit and
      // duplicate windows do not depend on the database server's time zone.
      timezone: "Z",
      connectionLimit: 10,
      waitForConnections: true,
      queueLimit: 50,
      connectTimeout: 10_000,
      enableKeepAlive: true,
    });
    pool.on("connection", (connection) => {
      connection.query("SET time_zone = '+00:00'");
    });
    const promisePool = pool.promise();
    instance = drizzle(promisePool, { mode: "planetscale", schema: fullSchema });
    closePool = () => promisePool.end();
  }
  return instance;
}

export async function closeDb(): Promise<void> {
  if (closePool) await closePool();
  instance = undefined;
  closePool = undefined;
}
