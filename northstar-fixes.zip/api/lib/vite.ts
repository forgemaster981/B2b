import type { Hono } from "hono";
import type { HttpBindings } from "@hono/node-server";
import { serveStatic } from "@hono/node-server/serve-static";
import fs from "fs";
import path from "path";
import { REDIRECTS, SPA_ROUTES } from "@contracts/routes";

type App = Hono<{ Bindings: HttpBindings }>;

const knownRoutes = new Set<string>(SPA_ROUTES);

export function serveStaticFiles(app: App) {
  const distPath = path.resolve(import.meta.dirname, "../dist/public");
  let indexHtml: string | undefined;
  const readIndex = () => (indexHtml ??= fs.readFileSync(path.resolve(distPath, "index.html"), "utf-8"));

  app.use("*", serveStatic({
    root: "./dist/public",
    onFound: (filePath, c) => {
      if (filePath.endsWith("index.html")) c.header("Cache-Control", "no-cache");
      // Vite emits content-hashed filenames under /assets, so they can be cached forever.
      else if (filePath.includes("/assets/")) c.header("Cache-Control", "public, max-age=31536000, immutable");
      else c.header("Cache-Control", "public, max-age=3600");
    },
  }));

  app.notFound((c) => {
    const accept = c.req.header("accept") ?? "";
    if (!accept.includes("text/html")) return c.json({ error: "Not Found" }, 404);
    const pathname = c.req.path.length > 1 ? c.req.path.replace(/\/+$/, "") : c.req.path;
    const redirect = REDIRECTS[pathname];
    if (redirect) return c.redirect(redirect, 301);
    c.header("Cache-Control", "no-cache");
    // Known pages get 200; anything else still renders the SPA's 404 screen but with a real 404 status
    // so search engines do not index soft-404s.
    return c.html(readIndex(), knownRoutes.has(pathname) ? 200 : 404);
  });
}
