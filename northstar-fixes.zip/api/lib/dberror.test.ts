import { describe, expect, it } from "vitest";
import { describeError, isDuplicateEntryError } from "./dberror";

describe("isDuplicateEntryError", () => {
  it("detects a raw mysql2 duplicate error", () => {
    expect(isDuplicateEntryError(Object.assign(new Error("Duplicate entry"), { code: "ER_DUP_ENTRY", errno: 1062 }))).toBe(true);
  });

  it("detects a duplicate wrapped by Drizzle, whose message does not contain the word 'Duplicate'", () => {
    const cause = Object.assign(new Error("Duplicate entry 'x' for key 'submission_id'"), { code: "ER_DUP_ENTRY", errno: 1062 });
    const wrapped = new Error("Failed query: insert into `inquiries` ...", { cause });
    expect(isDuplicateEntryError(wrapped)).toBe(true);
  });

  it("does not match other database errors or non-errors", () => {
    expect(isDuplicateEntryError(Object.assign(new Error("boom"), { code: "ER_LOCK_DEADLOCK", errno: 1213 }))).toBe(false);
    expect(isDuplicateEntryError(null)).toBe(false);
    expect(isDuplicateEntryError("ER_DUP_ENTRY")).toBe(false);
  });
});

describe("describeError", () => {
  it("never includes bound query parameters (visitor PII)", () => {
    const cause = Object.assign(new Error("Duplicate entry"), { code: "ER_DUP_ENTRY", errno: 1062, sqlState: "23000" });
    const error = new Error("Failed query: insert into inquiries (email) values (?)\nparams: jane@example.com,secret message", { cause });
    const text = JSON.stringify(describeError(error));
    expect(text).not.toContain("jane@example.com");
    expect(text).not.toContain("secret message");
    expect(text).toContain("ER_DUP_ENTRY");
    expect(text).toContain("23000");
  });
});
