import "dotenv/config";

const isProduction = process.env.NODE_ENV === "production";

function read(name: string): string {
  return (process.env[name] ?? "").trim();
}

function required(name: string): string {
  const value = read(name);
  if (!value && isProduction) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
}

function integer(name: string, fallback: number, min: number, max: number): number {
  const raw = read(name);
  if (!raw) {
    if (isProduction) throw new Error(`Missing required environment variable: ${name}`);
    return fallback;
  }
  const value = Number(raw);
  if (!Number.isInteger(value) || value < min || value > max) {
    throw new Error(`${name} must be an integer between ${min} and ${max}`);
  }
  return value;
}

const hashSecret = required("CONTACT_HASH_SECRET");
if (isProduction && hashSecret.length < 32) {
  throw new Error("CONTACT_HASH_SECRET must be at least 32 characters in production");
}

export const env = {
  isProduction,
  databaseUrl: required("DATABASE_URL"),
  // Signs form tokens and keys the IP/content hashes. Never reuse DATABASE_URL.
  contactHashSecret: hashSecret,
  // Number of reverse proxies in front of the app that append to X-Forwarded-For.
  // 0 = the app is directly exposed (header ignored). Must be set explicitly in production
  // because a wrong value either collapses all visitors into one rate-limit bucket (too low)
  // or lets visitors spoof their IP (too high).
  trustProxyHops: integer("TRUST_PROXY_HOPS", 0, 0, 5),
};
