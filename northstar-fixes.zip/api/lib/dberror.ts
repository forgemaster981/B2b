type ErrorLike = { name?: unknown; message?: unknown; code?: unknown; errno?: unknown; sqlState?: unknown; cause?: unknown };

/** True when any error in the cause chain is a MySQL duplicate-key violation (ER_DUP_ENTRY / 1062). */
export function isDuplicateEntryError(error: unknown): boolean {
  let current: unknown = error;
  for (let depth = 0; depth < 6 && current && typeof current === "object"; depth += 1) {
    const candidate = current as ErrorLike;
    if (candidate.code === "ER_DUP_ENTRY" || candidate.errno === 1062) return true;
    current = candidate.cause;
  }
  return false;
}

/**
 * Loggable summary of an error that never includes bound query parameters.
 * Drizzle puts "params: ..." (visitor name, email, message) inside Error.message,
 * so the message is cut before that marker.
 */
export function describeError(error: unknown): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  let current: unknown = error;
  for (let depth = 0; depth < 6 && current && typeof current === "object"; depth += 1) {
    const candidate = current as ErrorLike;
    const prefix = depth === 0 ? "" : `cause${depth}`;
    const key = (name: string) => (prefix ? `${prefix}${name[0].toUpperCase()}${name.slice(1)}` : name);
    if (typeof candidate.name === "string") out[key("name")] = candidate.name;
    if (typeof candidate.message === "string") out[key("message")] = candidate.message.split("\nparams:")[0].slice(0, 300);
    if (typeof candidate.code === "string" || typeof candidate.code === "number") out[key("code")] = candidate.code;
    if (typeof candidate.errno === "number") out[key("errno")] = candidate.errno;
    if (typeof candidate.sqlState === "string") out[key("sqlState")] = candidate.sqlState;
    current = candidate.cause;
  }
  return out;
}
