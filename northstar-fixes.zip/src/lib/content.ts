// Set VITE_SITE_URL at build time for the production domain (no trailing slash needed).
export const SITE_URL = (import.meta.env.VITE_SITE_URL || "https://northstar-student-studio.lovable.app").replace(/\/+$/, "");
export const GITHUB_URL = "https://github.com/Nikolatesla1857";

export const projects = [
  {
    type: "Student hackathon project · Team Alwan",
    title: "Phishing Detection — Cyber AI Hackathon",
    description: "Contributed as a member of Team Alwan to a hackathon project exploring how AI can help flag phishing attempts.",
    details: ["Explored signals that commonly indicate phishing, such as suspicious links and urgent language.", "Worked alongside teammates under hackathon time constraints.", "A learning project — not a deployed product."],
    tags: ["AI", "Cybersecurity", "Teamwork"],
  },
  {
    type: "Ongoing learning journey",
    title: "Python & DSA Practice",
    description: "Building fundamentals through regular Python practice and data structures & algorithms problems.",
    details: ["Working through arrays, strings, recursion and core problem patterns.", "Focus on consistency and clear reasoning over speed.", "A work in progress, not a finished product."],
    tags: ["Python", "DSA", "Fundamentals"],
  },
];

export const services = [
  { title: "Business websites & landing pages", description: "Simple, fast pages that explain what you do and make it easy to get in touch.", scope: "Typically 1–5 pages, mobile-first, built on modern tools." },
  { title: "Lead capture & contact forms", description: "Forms and calls-to-action that turn visitors into enquiries you can actually follow up on.", scope: "Secure forms connected to email or a simple sheet you control." },
  { title: "Local SEO foundations", description: "The groundwork search engines expect: titles, descriptions, structure and local signals.", scope: "Foundations only — no ranking guarantees." },
  { title: "Online presence setup", description: "Help getting your basics in order — Google Business Profile, consistent listings and social profiles.", scope: "Setup and guidance; you keep ownership of every account." },
  { title: "Content strategy", description: "A clear plan for what to say, where, and how often — written in your customers' language.", scope: "A practical content outline, not a guaranteed audience." },
  { title: "AI-assisted workflow ideas", description: "Exploring where AI tools could save time on replies, drafts or admin — thoughtfully.", scope: "Ideas and small experiments, reviewed by a human." },
];
