import { Link } from "react-router";
import { ArrowLeft } from "lucide-react";
import { Seo } from "@/components/Seo";

export default function NotFound() {
  return (
    <section className="not-found dark-section">
      <Seo title="Page not found — Northstar Student Studio" description="The requested page could not be found." noindex />
      <div>
        <p className="mono-label">404 / Off course</p>
        <h1>This page isn’t on the map.</h1>
        <p>The address may have changed, or the page may no longer exist.</p>
        <Link to="/" className="button primary"><ArrowLeft aria-hidden="true" />Back to home</Link>
      </div>
    </section>
  );
}
