import { Seo } from "@/components/Seo";
import { ContactForm } from "@/components/ContactForm";
import { TRPCProvider } from "@/providers/trpc";
import { GITHUB_URL } from "@/lib/content";

export default function Contact() {
  return (
    <>
      <Seo title="Contact — Mohammad Taufeeq & Northstar Growth Studio" description="Contact Mohammad Taufeeq about a student project, collaboration or practical website and digital growth support for your small business." path="/contact" />
      <section className="contact-page dark-section">
        <div className="container contact-grid">
          <div className="contact-intro">
            <p className="mono-label">Contact / Start with context</p>
            <h1>Let’s make the<br />next step clear.</h1>
            <p>Whether it’s a student project, a collaboration, or help for your business, share what you’re working on and what you need.</p>
            <div className="contact-expect">
              <h2>What happens next</h2>
              <ol>
                <li><span>01</span>Your inquiry is validated and securely saved.</li>
                <li><span>02</span>Email delivery is confirmed separately—not assumed.</li>
                <li><span>03</span>You receive a reference for this submission.</li>
              </ol>
            </div>
            <p className="contact-alternate">Prefer code? <a href={GITHUB_URL} target="_blank" rel="noopener noreferrer">Find me on GitHub ↗<span className="sr-only"> (opens in a new tab)</span></a></p>
          </div>
          <TRPCProvider><ContactForm /></TRPCProvider>
        </div>
      </section>
    </>
  );
}
