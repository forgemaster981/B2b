import { lazy, Suspense } from "react";
import { Navigate, Route, Routes } from "react-router";
import { Layout } from "@/components/Layout";
import Home from "./pages/Home";

// Everything except the landing page is split into its own chunk.
const About = lazy(() => import("./pages/About"));
const Projects = lazy(() => import("./pages/Projects"));
const Lab = lazy(() => import("./pages/Lab"));
const Insights = lazy(() => import("./pages/Insights"));
const Studio = lazy(() => import("./pages/Studio"));
const Contact = lazy(() => import("./pages/Contact"));
const Privacy = lazy(() => import("./pages/Privacy"));
const NotFound = lazy(() => import("./pages/NotFound"));

export default function App() {
  return (
    <Layout>
      <Suspense fallback={<div className="route-fallback" role="status" aria-live="polite"><span className="sr-only">Loading page…</span></div>}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/lab" element={<Lab />} />
          <Route path="/insights" element={<Insights />} />
          <Route path="/studio" element={<Studio />} />
          <Route path="/services" element={<Navigate to="/studio" replace />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Suspense>
    </Layout>
  );
}
