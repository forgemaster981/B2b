import { useEffect, useRef, useState, type ReactNode } from "react";
import { Link, NavLink, useLocation } from "react-router";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { GITHUB_URL } from "@/lib/content";

const navigation = [
  ["About", "/about"], ["Projects", "/projects"], ["Learning Lab", "/lab"], ["Notes", "/insights"], ["Studio", "/studio"], ["Contact", "/contact"],
];

export function Layout({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const main = useRef<HTMLElement>(null);
  const firstRender = useRef(true);

  // Route changes: close the menu, then either jump to the #anchor (pages load lazily, so the target
  // may not exist yet — retry briefly) or reset scroll, and move focus to <main> for keyboard/screen-reader users.
  useEffect(() => {
    setOpen(false);
    const hash = decodeURIComponent(location.hash.slice(1));
    let attempts = 0;
    let timer: number | undefined;
    const scrollToHash = () => {
      const target = hash ? document.getElementById(hash) : null;
      if (target) {
        target.scrollIntoView();
        return;
      }
      attempts += 1;
      if (attempts < 40) timer = window.setTimeout(scrollToHash, 50);
    };
    if (hash) scrollToHash();
    else window.scrollTo(0, 0);
    if (firstRender.current) firstRender.current = false;
    else main.current?.focus({ preventScroll: true });
    return () => window.clearTimeout(timer);
  }, [location.pathname, location.hash]);

  useEffect(() => {
    if (!open) return;
    const close = (event: KeyboardEvent) => { if (event.key === "Escape") setOpen(false); };
    document.addEventListener("keydown", close);
    return () => document.removeEventListener("keydown", close);
  }, [open]);

  return (
    <div className="min-h-dvh bg-paper text-ink">
      <a href="#main-content" className="skip-link">Skip to content</a>
      <header className="site-header">
        <div className="nav-shell">
          <Link to="/" className="brand" aria-label="Northstar Student Studio home">
            <svg viewBox="0 0 32 32" aria-hidden="true"><path d="M16 1l3.3 11.7L31 16l-11.7 3.3L16 31l-3.3-11.7L1 16l11.7-3.3L16 1z" fill="currentColor" /><circle cx="16" cy="16" r="3" fill="var(--paper)" /></svg>
            <span><strong>northstar</strong><small>student · studio</small></span>
          </Link>
          <nav className="desktop-nav" aria-label="Primary navigation">
            {navigation.map(([label, to]) => <NavLink key={to} to={to} className={({ isActive }) => isActive ? "active" : ""}>{label}</NavLink>)}
          </nav>
          <button className="menu-button" type="button" aria-expanded={open} aria-controls="mobile-navigation" aria-label={open ? "Close navigation" : "Open navigation"} onClick={() => setOpen(!open)}>{open ? <X aria-hidden="true" /> : <Menu aria-hidden="true" />}</button>
        </div>
        {open && <nav id="mobile-navigation" className="mobile-nav" aria-label="Mobile navigation">{navigation.map(([label, to]) => <NavLink key={to} to={to}>{label}<ArrowUpRight aria-hidden="true" /></NavLink>)}</nav>}
      </header>
      <main id="main-content" ref={main} tabIndex={-1}>{children}</main>
      <footer className="footer">
        <div className="container footer-grid">
          <div><Link to="/" className="footer-brand">Northstar<span aria-hidden="true">↗</span></Link><p>One student. Two honest pursuits.<br />Technology, learning and practical growth.</p></div>
          <div><p className="footer-label">Explore</p><Link to="/projects">Student projects</Link><Link to="/lab">Learning lab</Link><Link to="/insights">Notes</Link></div>
          <div><p className="footer-label">Studio</p><Link to="/studio">Services</Link><Link to="/contact">Start an inquiry</Link><Link to="/privacy">Privacy</Link></div>
          <div><p className="footer-label">Elsewhere</p><a href={GITHUB_URL} target="_blank" rel="noopener noreferrer">GitHub <ArrowUpRight aria-hidden="true" /><span className="sr-only"> (opens in a new tab)</span></a></div>
        </div>
        <div className="container footer-bottom"><span>© {new Date().getFullYear()} Mohammad Taufeeq</span><span>Independent studio project · Working name</span></div>
      </footer>
    </div>
  );
}
