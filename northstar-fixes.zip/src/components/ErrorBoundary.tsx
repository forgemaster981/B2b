import { Component, type ErrorInfo, type ReactNode } from "react";
import { log } from "@/lib/logger";

type State = { failed: boolean };

export class ErrorBoundary extends Component<{ children: ReactNode }, State> {
  state: State = { failed: false };

  static getDerivedStateFromError(): State {
    return { failed: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    log.error("render error", { message: error.message, stack: error.stack, componentStack: info.componentStack ?? undefined });
  }

  render() {
    if (!this.state.failed) return this.props.children;
    return (
      <div className="app-error" role="alert">
        <h1>Something went wrong.</h1>
        <p>The page failed to load. Reloading usually fixes it.</p>
        <button className="button primary" type="button" onClick={() => window.location.reload()}>Reload page</button>
      </div>
    );
  }
}
