import { useState } from "react";
import { Link } from "react-router";
import { ArrowRight, Check, RotateCcw } from "lucide-react";

const questions = [
  "Can a new customer understand what you offer within 10 seconds?",
  "Does your website work comfortably on a mobile phone?",
  "Is there one clear way to call, message or enquire?",
  "Are your business details consistent across search and social profiles?",
  "Do your pages answer the questions customers ask before buying?",
];

export function GrowthCheck() {
  const [answers, setAnswers] = useState<boolean[]>([]);
  const complete = answers.length === questions.length;
  const score = answers.filter(Boolean).length;
  return (
    <div className="growth-check">
      {!complete ? <>
        <div className="check-progress"><span aria-live="polite">Question {answers.length + 1} of {questions.length}</span><span>{Math.round(answers.length / questions.length * 100)}%</span></div>
        <div className="progress-track" aria-hidden="true"><span style={{ width: `${answers.length / questions.length * 100}%` }} /></div>
        <fieldset><legend>{questions[answers.length]}</legend><div className="check-actions"><button type="button" className="button primary" onClick={() => setAnswers([...answers, true])}><Check aria-hidden="true" />Yes</button><button type="button" className="button secondary" onClick={() => setAnswers([...answers, false])}>Not yet</button></div></fieldset>
        {answers.length > 0 && <button type="button" className="back-button" onClick={() => setAnswers(answers.slice(0, -1))}>Back to previous question</button>}
      </> : <div className="check-result" role="status">
        <p className="mono-label">Your practical starting point</p>
        <h3>{score} of {questions.length} foundations are in place.</h3>
        <p>{score === 5 ? "Your basics look strong. A review can still help uncover messaging and conversion gaps." : "Start with the items marked “Not yet”. Clear positioning, mobile usability and an easy inquiry path usually come before more content or advertising."}</p>
        <ul>{questions.map((question, index) => <li key={question} className={answers[index] ? "done" : "todo"}>{answers[index] ? <Check aria-hidden="true" /> : <span aria-hidden="true">→</span>}<span className="sr-only">{answers[index] ? "In place: " : "Not yet: "}</span>{question}</li>)}</ul>
        <div className="check-actions"><Link className="button primary" to="/contact?type=business">Discuss the gaps<ArrowRight aria-hidden="true" /></Link><button type="button" className="button secondary" onClick={() => setAnswers([])}><RotateCcw aria-hidden="true" />Start again</button></div>
        <small>Nothing is stored or sent. This is guidance, not a performance audit.</small>
      </div>}
    </div>
  );
}
