import { useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Link, useSearchParams } from "react-router";
import { ArrowRight, CheckCircle2, LoaderCircle } from "lucide-react";
import { contactFieldsSchema, type ContactFields } from "@contracts/contact";
import { trpc } from "@/providers/trpc";

const labels: Record<ContactFields["inquiryType"], string> = { business: "Business / studio", project: "Student project", collaboration: "Collaboration", other: "Something else" };

const notices = {
  sent: "Your inquiry was saved and the studio inbox was notified.",
  duplicate: "This inquiry was already received. No duplicate was created.",
  failed: "Your inquiry was saved, but the email notification to the studio could not be delivered. If you don’t hear back, please reach out via GitHub and quote your reference.",
  unconfigured: "Your inquiry was saved. Email notifications are not enabled on this site yet, so a reply may take longer.",
} as const;

function friendlyError(message: string): string {
  if (/failed to fetch|networkerror|load failed/i.test(message)) return "Couldn’t reach the server. Check your connection and try again.";
  return message;
}

function newDefaults(inquiryType: ContactFields["inquiryType"]): ContactFields {
  return { name: "", email: "", inquiryType, message: "", website: "", submissionId: crypto.randomUUID() };
}

export function ContactForm() {
  const [params] = useSearchParams();
  const requested = params.get("type");
  const initialType = requested && requested in labels ? requested as ContactFields["inquiryType"] : "business";
  const [reference, setReference] = useState("");
  const [notice, setNotice] = useState("");
  const statusRef = useRef<HTMLDivElement>(null);

  const { register, handleSubmit, reset, formState: { errors } } = useForm<ContactFields>({
    resolver: zodResolver(contactFieldsSchema),
    defaultValues: newDefaults(initialType),
  });

  // Signed token from the server; proves the form was loaded and open for a moment (anti-bot).
  const formToken = trpc.contact.formToken.useQuery(undefined, { staleTime: 60 * 60 * 1000, gcTime: 0 });

  const submit = trpc.contact.submit.useMutation({
    onSuccess: (result) => {
      setReference(result.reference);
      setNotice(notices[result.notification]);
      reset(newDefaults(initialType));
      void formToken.refetch();
    },
    onError: (error) => {
      // A stale/invalid token is fixed by fetching a fresh one.
      if (error.data?.code === "BAD_REQUEST") void formToken.refetch();
    },
  });

  useEffect(() => {
    if (notice) statusRef.current?.focus();
  }, [notice]);

  const onSubmit = (data: ContactFields) => {
    const token = formToken.data?.token;
    if (!token) return;
    setNotice("");
    submit.mutate({ ...data, formToken: token });
  };

  const fieldError = (name: keyof ContactFields) => errors[name]?.message ? <span className="field-error" id={`${name}-error`}>{String(errors[name]?.message)}</span> : null;
  const ready = Boolean(formToken.data?.token);

  return (
    <form className="contact-form" onSubmit={handleSubmit(onSubmit)} noValidate>
      <div className="form-row">
        <div className="field"><label htmlFor="name">Name</label><input id="name" autoComplete="name" placeholder="Your name" aria-invalid={!!errors.name} aria-describedby={errors.name ? "name-error" : undefined} {...register("name")} />{fieldError("name")}</div>
        <div className="field"><label htmlFor="email">Email</label><input id="email" type="email" inputMode="email" autoComplete="email" placeholder="you@company.com" aria-invalid={!!errors.email} aria-describedby={errors.email ? "email-error" : undefined} {...register("email")} />{fieldError("email")}</div>
      </div>
      <div className="field"><label htmlFor="inquiryType">What’s this about?</label><select id="inquiryType" aria-invalid={!!errors.inquiryType} {...register("inquiryType")}>{Object.entries(labels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select>{fieldError("inquiryType")}</div>
      <div className="field"><label htmlFor="message">Message</label><textarea id="message" rows={6} placeholder="A little context, what you need, and any useful links…" aria-invalid={!!errors.message} aria-describedby={errors.message ? "message-error" : "message-hint"} {...register("message")} /><span id="message-hint" className="field-hint">20–3,000 characters. Please don’t include passwords or sensitive data.</span>{fieldError("message")}</div>
      <div className="honeypot" aria-hidden="true"><label htmlFor="website">Website</label><input id="website" tabIndex={-1} autoComplete="off" {...register("website")} /></div>
      <input type="hidden" {...register("submissionId")} />
      {formToken.isError && <div className="form-status error" role="alert">The form couldn’t be prepared. Please reload the page and try again.</div>}
      {submit.error && <div className="form-status error" role="alert">{friendlyError(submit.error.message)}</div>}
      {notice && <div className="form-status success" role="status" tabIndex={-1} ref={statusRef}><CheckCircle2 aria-hidden="true" /><div><strong>Inquiry received</strong><p>{notice}</p><small>Reference: {reference.slice(0, 8).toUpperCase()}</small></div></div>}
      <div className="form-footer"><p>By submitting, you agree to the <Link to="/privacy">privacy policy</Link>. Your details are used only to handle this inquiry.</p><button className="button primary" type="submit" disabled={submit.isPending || !ready}>{submit.isPending ? <><LoaderCircle className="spin" aria-hidden="true" />Sending…</> : <>Send inquiry<ArrowRight aria-hidden="true" /></>}</button></div>
    </form>
  );
}
