import devServer from "@hono/vite-dev-server";
import path from "path";
import react from "@vitejs/plugin-react";
import { defineConfig, loadEnv, type Plugin } from "vite";
import { SPA_ROUTES, SITEMAP_PRIORITY } from "./contracts/routes";

const __dirname = import.meta.dirname;
const FALLBACK_SITE_URL = "https://northstar-student-studio.lovable.app";

/** Single source of truth for the public URL: fills index.html and emits sitemap.xml / robots.txt. */
function siteMeta(siteUrl: string): Plugin {
  return {
    name: "site-meta",
    transformIndexHtml: (html) => html.replaceAll("__SITE_URL__", siteUrl),
    generateBundle() {
      const urls = SPA_ROUTES.map((route) => {
        const priority = SITEMAP_PRIORITY[route];
        return `  <url><loc>${siteUrl}${route}</loc>${priority ? `<priority>${priority}</priority>` : ""}</url>`;
      }).join("\n");
      this.emitFile({ type: "asset", fileName: "sitemap.xml", source: `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n` });
      this.emitFile({ type: "asset", fileName: "robots.txt", source: `User-agent: *\nAllow: /\nDisallow: /api/\n\nSitemap: ${siteUrl}/sitemap.xml\n` });
    },
  };
}

// https://vite.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, __dirname, "VITE_");
  const siteUrl = (env.VITE_SITE_URL || FALLBACK_SITE_URL).replace(/\/+$/, "");
  return {
    plugins: [
      devServer({ entry: "api/boot.ts", exclude: [/^\/(?!api\/).*$/] }),
      react(),
      siteMeta(siteUrl),
    ],
    server: { port: 3000 },
    resolve: {
      alias: {
        "@": path.resolve(__dirname, "./src"),
        "@contracts": path.resolve(__dirname, "./contracts"),
        "@db": path.resolve(__dirname, "./db"),
        "db": path.resolve(__dirname, "./db"),
      },
    },
    envDir: path.resolve(__dirname),
    build: {
      outDir: path.resolve(__dirname, "dist/public"),
      emptyOutDir: true,
      target: "es2022",
    },
  };
});
