# Northstar Student Studio

Dual-brand portfolio for Mohammad Taufeeq and Northstar Growth Studio. React 19, TypeScript, Vite, Hono, tRPC, Drizzle ORM, MySQL.

## Local development

```bash
cp .env.example .env        # fill in DATABASE_URL at minimum
npm install
npm run db:push             # creates the tables in the database from DATABASE_URL
npm run dev                 # http://localhost:3000
```

Checks:

```bash
npm run check    # type-check (tsc -b)
npm run lint
npm test
npm run build    # client -> dist/public, server + admin CLI -> dist/boot.js, dist/cli.js
```

## Environment variables

See `.env.example` for the full annotated list.

| Variable | Required | Purpose |
| --- | --- | --- |
| `DATABASE_URL` | always (prod) | MySQL/MariaDB connection string |
| `CONTACT_HASH_SECRET` | prod, >= 32 chars | Signs form tokens, keys IP/duplicate hashes |
| `TRUST_PROXY_HOPS` | prod | Reverse proxies in front of the app (0 = none, 1 = typical PaaS) |
| `RESEND_API_KEY`, `CONTACT_TO_EMAIL` | optional | Email notification; inquiries are saved either way |
| `CONTACT_FROM_EMAIL` | optional | Sender on a Resend-verified domain |
| `PORT` | optional | Defaults to 3000 |
| `VITE_SITE_URL` | build time | Public origin for canonical URLs, sitemap, Open Graph |

`VITE_*` values are embedded in the public bundle. Never put secrets in them.

## Contact flow

1. The page asks `contact.formToken` for an HMAC-signed timestamp.
2. `contact.submit` validates the shared Zod schema, verifies the token (>= 3 s old, < 6 h old), checks the honeypot, applies a 5-per-15-minutes limit keyed on a hashed client IP, and de-duplicates by submission id and content fingerprint.
3. The inquiry is saved first. The email is sent afterwards, and the UI reports exactly one of: sent, duplicate, failed, or notifications not enabled.

Inquiries have no public read endpoint. Use the admin CLI (needs the same environment as the server):

```bash
npm run build
npm run admin -- list 20        # newest inquiries
npm run admin -- retry          # resend notifications that failed / were never configured
npm run admin -- purge 365      # delete inquiries older than 365 days + stale rate-limit rows
```

Schedule `purge` (cron / platform scheduler) if you want the retention behaviour described in `/privacy`.

## Deployment

1. Provision a MySQL/MariaDB database. Set the variables above on the host (never commit them).
2. Build: `npm ci && VITE_SITE_URL=https://your-domain npm run build`.
3. Apply the schema: development `npm run db:push`; production `npm run db:generate` once, commit `db/migrations`, then `npm run db:migrate` on deploy.
4. Start: `npm start` (or the Dockerfile: `docker build --build-arg VITE_SITE_URL=https://your-domain -t northstar .`).
5. Verify: `GET /api/health` returns `{"status":"ok"}`; submit a test inquiry and confirm it with `npm run admin -- list`.
6. Serve over HTTPS (HSTS is sent in production). In Resend, verify your sender domain and set `CONTACT_FROM_EMAIL`.
7. Submit `https://your-domain/sitemap.xml` (generated at build) to Google Search Console.

## Security notes

- Production CSP: scripts from `self` only; no inline scripts; connections to `self` only.
- Errors returned to the browser are generic; server logs never include query parameters.
- `/api/log` (browser log sink) exists in development only. Production logs go to stdout.
- Run `npm run audit:prod` before each release.
